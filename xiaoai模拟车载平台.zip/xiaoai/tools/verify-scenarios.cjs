const fs = require("fs");
const vm = require("vm");

let code = fs.readFileSync("script.js", "utf8").replace(/\ninit\(\);\s*$/, "");
code += `
const rows = scenarioRecords.map((record) => {
  const result = classifyInput(record.input);
  const tonePass =
    Boolean(result.output) &&
    !/(记录口径|建议记录|系统输出|你的评价|仿真)/.test(result.output) &&
    !/(我识别当前|我先识别|我先扫描|发送到车机导航|当前先按|满足条件|该功能|系统将|用户可)/.test(result.output) &&
    !/(我帮你看一下。我帮你看一下|好呀，好呀|我在呢。我在呢)/.test(result.output) &&
    !/^(我会保持安静|我会尽量少打扰|我会在|这个动作需要|该功能|当前条件)/.test(result.output) &&
    /(好|我|可以|收到|听到了|听起来|没事|可能|不是|刚才|因为|这条路|最近|具体|简单|这个)/.test(result.output.slice(0, 12));
  return {
    id: record.id || record.title,
    input: record.input,
    title: result.title,
    output: result.output,
    rating: result.rating,
    pass: Boolean(result.output && result.output.length > 8 && result.rating && tonePass),
    tonePass,
  };
});
globalThis.__check = {
  total: rows.length,
  pass: rows.filter((row) => row.pass).length,
  fail: rows.filter((row) => !row.pass),
  required: rows.filter((row) => String(row.id).startsWith("S")).length,
  xiaomi: rows.filter((row) => String(row.id).startsWith("XM")).length,
  legacy: rows.filter((row) => !String(row.id).startsWith("S") && !String(row.id).startsWith("XM")).length,
};
`;

const context = { window: {}, console };
vm.createContext(context);
vm.runInContext(code, context);

console.log(JSON.stringify(context.__check, null, 2));
