(function () {
  'use strict';

  console.log('✅【ASR高亮脚本】已成功注入，开始初始化...');

  // ========== 1. 双色高亮样式（核心修改：两种差异色） ==========
  const style = document.createElement('style');
  style.textContent = `
  /* ASR1独有的差异字符 - 浅黄色背景 */
  .diff-highlight-asr1 {
    background: #ffe58f !important; /* ASR1差异色 */
    border-radius: 3px !important;
    padding: 0 1px !important;
    color: #000 !important;
    display: inline !important;
  }
  /* ASR2独有的差异字符 - 浅蓝色背景 */
  .diff-highlight-asr2 {
    background: #8fc3ff !important; /* ASR2差异色 */
    border-radius: 3px !important;
    padding: 0 1px !important;
    color: #000 !important;
    display: inline !important;
  }
  /* 原始文本容器样式保留（不新增对比框） */
  .asr-original-wrapper {
    position: relative !important;
    line-height: 1.6 !important;
    font-size: 13px !important;
    box-sizing: border-box !important;
  }
  `;
  document.head.appendChild(style);

  // ========== 2. 工具函数（保留核心，适配双色渲染） ==========
  const debounce = (fn, wait = 300) => {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), wait);
    };
  };

  const escapeHtml = (str) => {
    return str ? str.replace(/[&<>"']/g, m => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[m])) : '';
  };

  function normalizeForDiff(s) {
    if (typeof s !== 'string' || s.length === 0) return s;
    return typeof s.normalize === 'function' ? s.normalize('NFC') : s;
  }

  function isIgnorableDiffChar(ch) {
    if (ch == null || ch === '') return true;
    const units = Array.from(ch);
    if (units.length !== 1) return units.every(isIgnorableDiffChar);
    const cp = ch.codePointAt(0);
    if (cp === 0x20 || cp === 0x09 || cp === 0x0a || cp === 0x0b || cp === 0x0c || cp === 0x0d) return true;
    if (cp === 0xa0 || cp === 0x3000) return true;
    if (cp === 0xfeff) return true;
    if (cp >= 0x200b && cp <= 0x200f) return true;
    if (cp >= 0x2028 && cp <= 0x2029) return true;
    if (cp >= 0x2060 && cp <= 0x2064) return true;
    try {
      if (/\p{Z}/u.test(ch)) return true;
      if (/\p{Cf}/u.test(ch)) return true;
    } catch (e) {}
    return false;
  }

  function stripIgnorableHighlight(arr) {
    arr.forEach((item) => {
      if (item.d && isIgnorableDiffChar(item.t)) item.d = 0;
    });
  }

  // ========== 3. 核心修改：双色渲染差异（区分ASR1/ASR2） ==========
  function renderDiffSegmentsASR1(arr) {
    let html = '';
    let i = 0;
    while (i < arr.length) {
      const it = arr[i];
      if (!it.d) {
        html += escapeHtml(it.t);
        i++;
        continue;
      }
      let j = i;
      while (j < arr.length && arr[j].d) j++;
      const seg = arr.slice(i, j).map((x) => x.t).join('');
      html += `<span class="diff-highlight-asr1">${escapeHtml(seg)}</span>`;
      i = j;
    }
    return html;
  }

  function renderDiffSegmentsASR2(arr) {
    let html = '';
    let i = 0;
    while (i < arr.length) {
      const it = arr[i];
      if (!it.d) {
        html += escapeHtml(it.t);
        i++;
        continue;
      }
      let j = i;
      while (j < arr.length && arr[j].d) j++;
      const seg = arr.slice(i, j).map((x) => x.t).join('');
      html += `<span class="diff-highlight-asr2">${escapeHtml(seg)}</span>`;
      i = j;
    }
    return html;
  }

  // ========== 4. 差异对比核心（保留算法，返回双色渲染结果） ==========
  const DIFF_MAX_LEN = 6000;
  const DIFF_MAX_CELLS = 2_800_000;

  function diffASRText(a, b) {
    const sa = normalizeForDiff(a == null ? '' : String(a));
    const sb = normalizeForDiff(b == null ? '' : String(b));
    if (sa.length === 0 && sb.length === 0) {
      return { aHtml: '', bHtml: '' };
    }

    const n = sa.length;
    const m = sb.length;
    if (n > DIFF_MAX_LEN || m > DIFF_MAX_LEN || n * m > DIFF_MAX_CELLS) {
      console.warn('⚠️ ASR过长，跳过差异高亮（避免卡顿）', { n, m });
      return { aHtml: escapeHtml(sa), bHtml: escapeHtml(sb) };
    }

    const A = Array.from(sa);
    const B = Array.from(sb);
    const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));

    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        dp[i][j] = A[i] === B[j] ? dp[i+1][j+1] + 1 : Math.max(dp[i+1][j], dp[i][j+1]);
      }
    }

    let i = 0, j = 0;
    const outA = [], outB = [];
    while (i < n && j < m) {
      if (A[i] === B[j]) {
        outA.push({ t: A[i], d: 0 });
        outB.push({ t: B[j], d: 0 });
        i++; j++;
      } else if (dp[i+1][j] >= dp[i][j+1]) {
        outA.push({ t: A[i], d: 1 }); // ASR1差异标记
        i++;
      } else {
        outB.push({ t: B[j], d: 1 }); // ASR2差异标记
        j++;
      }
    }
    while (i < n) { outA.push({ t: A[i], d: 1 }); i++; }
    while (j < m) { outB.push({ t: B[j], d: 1 }); j++; }

    stripIgnorableHighlight(outA);
    stripIgnorableHighlight(outB);

    return {
      aHtml: renderDiffSegmentsASR1(outA), // ASR1用浅黄色
      bHtml: renderDiffSegmentsASR2(outB)  // ASR2用浅蓝色
    };
  }

  // ========== 5. 文本提取（保留原有逻辑） ==========
  function extractASRContent(text) {
    const asr1Match = text.match(/asr_text1[:：]\s*(.+?)(?=\s*asr_text2[:：]|$)/s);
    const asr2Match = text.match(/asr_text2[:：]\s*([\s\S]+?)(?=\s*wav_id\s*[:：]|$)/i);
    const wavLine = text.match(/wav_id\s*[:：]?\s*(\S+)/i);

    if (asr1Match && asr2Match) {
      return {
        asr1: asr1Match[1].trim(),
        asr2: asr2Match[1].trim(),
        wavId: wavLine ? wavLine[1].trim() : null
      };
    }

    const re = /asr_text2\s*[:：]/gi;
    const matches = [...text.matchAll(re)];
    if (matches.length >= 2) {
      const s0 = matches[0].index + matches[0][0].length;
      const s1 = matches[1].index;
      const s2 = matches[1].index + matches[1][0].length;
      const asr1 = text.slice(s0, s1).trim();
      const tail = text.slice(s2);
      const wAt = tail.search(/wav_id\s*[:：]/i);
      const asr2 = (wAt >= 0 ? tail.slice(0, wAt) : tail).trim();
      return { asr1, asr2, wavId: wavLine ? wavLine[1].trim() : null };
    }

    return null;
  }

  // ========== 6. 核心修改：直接替换原始文本（无新对比框） ==========
  function findMinimalTextMount(textNode) {
    const full = (textNode.textContent || '').trim();
    if (!full) return null;
    let el = textNode.parentElement;
    if (!el) return null;
    while (el.parentElement) {
      const p = el.parentElement;
      if (p.querySelector && p.querySelector('audio, video')) break;
      const pt = (p.textContent || '').trim();
      if (pt === full) el = p;
      else break;
    }
    return el;
  }

  function injectDiffToOriginalText(mount, aHtml, bHtml) {
    if (!mount || mount.dataset.asrProcessed === 'true') return;
    if (mount.querySelector && mount.querySelector('audio, video')) return;

    // 核心修改：直接替换原始文本的HTML（保留原有结构，仅高亮差异）
    // 拼接ASR1和ASR2的高亮文本，替换原始内容
    const originalText = mount.textContent;
    // 保留wav_id等原始信息，仅替换ASR文本部分
    const wavIdMatch = originalText.match(/(wav_id\s*[:：]?\s*\S+)/i);
    const wavIdHtml = wavIdMatch ? `<div>${wavIdMatch[1]}</div>` : '';

    // 直接修改原始容器的HTML（无新增对比框）
    mount.innerHTML = `
      <div class="asr-original-wrapper">
        <div><strong>ASR1：</strong>${aHtml}</div>
        <div><strong>ASR2：</strong>${bHtml}</div>
        ${wavIdHtml}
      </div>
    `;
    mount.dataset.asrProcessed = 'true';
  }

  // ========== 7. 处理逻辑（适配新的注入方式） ==========
  function processAllASRContent() {
    let successCount = 0;
    let totalMatchCount = 0;

    // 路径1：匹配已知文本容器
    const containerSelectors = ['.dt-text-container', '.dt-text-wrapper', '.text-content', '.content-text'];
    const containers = document.querySelectorAll(containerSelectors.join(','));
    totalMatchCount += containers.length;

    containers.forEach((container) => {
      if (container.dataset.asrProcessed === 'true') return;
      if (container.querySelector && container.querySelector('audio, video')) return;
      const content = extractASRContent(container.textContent);
      if (!content) return;

      const { aHtml, bHtml } = diffASRText(content.asr1, content.asr2);
      injectDiffToOriginalText(container, aHtml, bHtml); // 注入到原始文本
      successCount++;
    });

    // 路径2：遍历所有文本节点兜底（优先处理页面最下方的文本）
    const textWalker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const txt = node.textContent;
          if (!txt || txt.length < 20) return NodeFilter.FILTER_SKIP;
          const has1 = /asr_text1/i.test(txt);
          const count2 = (txt.match(/asr_text2/gi) || []).length;
          if (has1 && count2 >= 1) return NodeFilter.FILTER_ACCEPT;
          if (count2 >= 2) return NodeFilter.FILTER_ACCEPT;
          return NodeFilter.FILTER_SKIP;
        }
      }
    );

    let textNode;
    const textNodes = [];
    // 先收集所有符合条件的文本节点
    while ((textNode = textWalker.nextNode())) {
      textNodes.push(textNode);
    }
    // 优先处理最后一个节点（页面最下方的原始文本）
    const targetTextNode = textNodes[textNodes.length - 1];
    if (targetTextNode) {
      const mount = findMinimalTextMount(targetTextNode);
      if (!mount || mount.dataset.asrProcessed === 'true') return;
      if (mount.querySelector && mount.querySelector('audio, video')) return;

      const content = extractASRContent(targetTextNode.textContent);
      if (!content) return;

      totalMatchCount++;
      const { aHtml, bHtml } = diffASRText(content.asr1, content.asr2);
      injectDiffToOriginalText(mount, aHtml, bHtml); // 注入到原始文本
      successCount++;
    }

    console.log(`📊【ASR高亮脚本】本次执行：共匹配${totalMatchCount}个目标节点，成功处理${successCount}个ASR文本`);
    return successCount;
  }

  // ========== 8. 触发逻辑（保留原有） ==========
  const debouncedProcess = debounce(processAllASRContent, 300);

  [1000, 2000, 3500, 5000].forEach(delay => {
    setTimeout(debouncedProcess, delay);
  });

  const globalObserver = new MutationObserver(debouncedProcess);
  globalObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    characterData: true
  });

  ['click', 'scroll', 'mouseup', 'keydown', 'load'].forEach(event => {
    document.addEventListener(event, debouncedProcess);
  });

  window.runASR = processAllASRContent;

  console.log('🎉【ASR高亮脚本】初始化完成！控制台输入 runASR() 可手动执行');
})();